-- Question 5> write a query to find the titles of all films that have rental rate higher than 
-- the average rental rate of all films

select AVG (film.rental_rate) from film;
select title, rental_rate 
from film
where rental_rate > (select AVG (film.rental_rate) from film);

