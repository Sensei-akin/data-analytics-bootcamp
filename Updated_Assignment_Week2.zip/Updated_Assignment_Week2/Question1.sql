-- Question: 1 Write a query to retrieve all the title and language of all film
SELECT film.title, language.name 
FROM film
JOIN language
ON film.language_id = language. language_id;

