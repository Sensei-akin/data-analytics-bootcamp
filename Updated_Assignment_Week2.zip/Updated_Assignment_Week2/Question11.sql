-- Question 12: Write a query to list all actors and the number of films they have appeared in.
-- Include actors who have not appeared in any film

SELECT a.first_name, a.last_name, COUNT(fa.film_id) AS film_count
FROM actor a
LEFT JOIN film_actor fa
ON a.actor_id = fa.actor_id
GROUP BY 1, 2
ORDER BY film_count DESC;





