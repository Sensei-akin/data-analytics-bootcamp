-- Question 10: Write a query to list each staff member, the number of rentals they have processed,
-- and the total revenue they have generated

SELECT s.first_name, s.last_name, COUNT(p.rental_id) AS rentals_processed,
SUM(p.amount) AS total_revenue
FROM staff s
JOIN payment p
ON s.staff_id = p.staff_id
GROUP BY 1, 2
ORDER BY total_revenue DESC;
