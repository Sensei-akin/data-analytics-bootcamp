-- Question 9: Write a query to find the customer who has spent the most money.
-- Display the customers's full name and total amount they have spent.

select c.first_name, c.last_name, COUNT(p.amount) As most_money
from customer c
join payment p
on c.customer_id = p.customer_id
GROUP BY 1, 2
ORDER BY (most_money) DESC;

