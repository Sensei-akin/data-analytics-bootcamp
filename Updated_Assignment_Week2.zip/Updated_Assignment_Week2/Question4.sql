-- Quetion 4: Write a query to find the number of films in each category. Display the category name
-- and the number of films.
select c.name, COUNT(fc.film_id) As film_count
from category c
join film_category fc
on c.category_id = fc.category_id
group by 1;
