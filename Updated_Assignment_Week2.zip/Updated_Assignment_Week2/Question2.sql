-- Question 2: write a query to find the total number of actors in the database.
select COUNT(actor_id) AS total_number
from actor;
