-- Question 6: write a query to calculate the total revenue for each store.
select s.store_id, SUM(p.amount) AS total_revenue
from store s
JOIN staff st
ON s.store_id = st.store_id
JOIN payment p
ON st.staff_id = p.staff_id
GROUP BY s.store_id;
