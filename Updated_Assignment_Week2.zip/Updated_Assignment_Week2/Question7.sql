
-- Question 7: Write a query to list the top 5 most rented films. 
-- Display the film title and the number of times it has been rented.
select f.title, COUNT(r.rental_id) AS most_rented
FROM film f
JOIN inventory i
ON f.film_id = i.film_id
Join rental r
ON i.inventory_id = r.inventory_id
GROUP BY f.title
ORDER BY most_rented DESC
LIMIT 5;
