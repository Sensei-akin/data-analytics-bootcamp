-- Question 8: Write a query to find the full names of all actors who have appeared in the film 
-- with the title 'AFRICAN EGG'

select a.first_name, a.last_name, f.title from actor a
join film_actor fa
on a.actor_id = fa.actor_id
join film f
on f.film_id = fa.film_id
where f.title = 'AFRICAN EGG';

